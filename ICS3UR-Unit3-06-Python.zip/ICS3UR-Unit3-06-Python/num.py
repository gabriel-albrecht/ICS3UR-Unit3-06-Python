#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This is another number guessing program


import random


def main():
    # this function uses a try statement

    # input
    number = int(input("Enter a number between 0-9: "))
    value = random.randint(0, 9)
    print("")

    # process
    if value == number:
        print("Congratulations! You picked the right number!")
    elif number > 9:
        print("ERROR: INVALID INTEGER")
    elif number < 0:
        print("ERROR: INVALID INTEGER")
    else:
        print("Wrong number! The correct number was:")
        print(value)


if __name__ == "__main__":
    main()
